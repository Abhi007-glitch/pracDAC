#include <iostream>
using namespace std;
int reverse1(int input,int rem,int reverse){
    reverse=0;
    rem=0;
while(input>0){
        rem=input%10;
        reverse =reverse*10+rem;
        input /=10;
    }return reverse;

}
int main() {
    
    int input, rem, temp, reverse;
    cin>>input;
    
    
    
    
    cout<<reverse1(input,rem,reverse);
    return 0;
}