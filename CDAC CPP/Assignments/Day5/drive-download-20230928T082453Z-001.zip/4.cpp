#include <iostream>

bool isPalindrome(int number) {
    int originalNumber = number;
    int reverseNumber = 0;

    while (number > 0) {
        int digit = number % 10;
        reverseNumber = reverseNumber * 10 + digit;
        number /= 10;
    }

    return originalNumber == reverseNumber;
}

int main() {
    int N;

    std::cout << "Enter a positive integer: ";
    std::cin >> N;

    if (isPalindrome(N)) {
        std::cout << N << " is a palindrome number." << std::endl;
    } else {
        std::cout << N << " is not a palindrome number." << std::endl;
    }

    return 0;
}
