#include <iostream>

using namespace std;

bool isPrime(int number) {
    if (number <= 1) {
        return false;
    }

    for (int i = 2; i * i <= number; i++) {
        if (number % i == 0) {
            return false;
        }
    }

    return true;
}

void findPrimes(int N, int M) {
    cout << "Prime numbers between " << N << " and " << M << " are: ";

    for (int i = N; i <= M; i++) {
        if (isPrime(i)) {
            cout << i << " ";
        }
    }

    cout << endl;
}

int main() {
    int N, M;

    cout << "Enter the value of N: ";
    cin >> N;

    cout << "Enter the value of M: ";
    cin >> M;

    findPrimes(N, M);

    return 0;
}
